import { BullModule } from "@nestjs/bull";
import { forwardRef, Module } from "@nestjs/common";

@Module({
  providers: [],
  imports: [],
})
export class JobProcessorModule {}
